function encontrarMaior(n1, n2, n3) {
  const maior = Math.max(n1, n2, n3);
  console.log("O maior número é: " + maior);
}