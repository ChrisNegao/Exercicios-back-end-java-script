function contarPares(lista) {
  let contador = 0;

  for (let num of lista) {
    if (num % 2 === 0) {
      contador++;
    }
  }

  return contador;
}