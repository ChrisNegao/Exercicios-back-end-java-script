function contarPalavras(frase) {
  let palavras = frase.trim().split(" ");
  return palavras.length;
}
