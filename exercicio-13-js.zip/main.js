function contarVogais(texto) {
  let contagem = 0;
  let vogais = "aeiouAEIOU";
  for (let letra of texto) {
    if (vogais.includes(letra)) {
      contagem++;
    }
  }
  return contagem;
}
