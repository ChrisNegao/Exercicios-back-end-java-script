function somarPositivos(arr) {
  let soma = 0;
  for (let num of arr) {
    if (num > 0) {
      soma += num;
    }
  }
  return soma;
}
