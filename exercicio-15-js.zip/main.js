function filtrarPares(arr) {
  let pares = [];
  for (let num of arr) {
    if (num % 2 === 0) {
      pares.push(num);
    }
  }
  return pares;
}
