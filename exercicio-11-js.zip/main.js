function segundoMaior(arr) {
  let maior = -Infinity;
  let segundo = -Infinity;

  for (let num of arr) {
    if (num > maior) {
      segundo = maior;
      maior = num;
    } else if (num > segundo && num !== maior) {
      segundo = num;
    }
  }
  return segundo;
}
