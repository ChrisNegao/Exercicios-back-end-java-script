function calcularMedia(notas) {
  let soma = 0;
  for (let nota of notas) {
    soma += nota;
  }

  let media = soma / notas.length;

  return media;
}

const minhasNotas = [7, 8, 10, 5];
console.log("A média é: " + calcularMedia(minhasNotas));
