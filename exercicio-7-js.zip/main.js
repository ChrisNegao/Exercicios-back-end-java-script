function encontrarMenorNumero(arr) {
  if (arr.length === 0) return undefined;
  
  let menor = arr[0];
  
  for (let i = 1; i < arr.length; i++) {
    if (arr[i] < menor) {
      menor = arr[i];
    }
  }
  return menor;
}