function mostrarNumeros(limite) {
  for (let i = 1; i <= limite; i++) {
    console.log(i);
  }
}


mostrarNumeros(5); 

