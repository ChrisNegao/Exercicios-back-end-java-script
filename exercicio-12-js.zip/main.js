function removerDuplicados(arr) {
  let unico = [];
  for (let i = 0; i < arr.length; i++) {
    if (unico.indexOf(arr[i]) === -1) {
      unico.push(arr[i]);
    }
  }
  return unico;
}
