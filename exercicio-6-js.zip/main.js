function contarLetraA(palavra) {
  let contador = 0;
  
  let palavraMinuscula = palavra.toLowerCase();

  for (let letra of palavraMinuscula) {
    if (letra === 'a') {
      contador++;
    }
  }

  return contador;
}
